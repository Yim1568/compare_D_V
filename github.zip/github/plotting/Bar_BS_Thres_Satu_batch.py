import os
import numpy as np
import matplotlib.pyplot as plt

# Basic input path
base_input_path = r'The parent directory of DS_DR_ME_L4ptr\'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']
colors = ['blue', 'green', 'red', 'orange']  # Colors for different fiber types


# General path retrieval function. Note the replacement of D and V
def get_input_path(base_folder, fiber_type, file_name='overall_bootstrap_analysis.txt'):
    return os.path.join(base_folder, fiber_type, 'rx', 'BS_result', file_name)


# Batch process folder mode
def batch_process_folders(base_input_path):
    folder_prefixes = ['D','V']  # Values of p
    o_range = range(2, 7)  # Range of o (2 to 6)
    i_range = range(2, 7)  # Range of i (1 to 6)
    m_range = range(2, 7)

    for p in folder_prefixes:
        for o in o_range:
            for i in i_range:
                for m in m_range:
                 # Construct three folder formats
                  folder_format1 = f'{p}S_{p}R_ME_L{o}ptr'
                  folder_format2 = f'{p}S_{p}R_ME_L{o}ptpL{i}'
                  folder_format3 = f'{p}S_{p}R_ME_L{o}_mL{m}_L{i}'


                # Two folder paths
                  folder_path1 = os.path.join(base_input_path, folder_format1)
                  folder_path2 = os.path.join(base_input_path, folder_format2)
                  folder_path3 = os.path.join(base_input_path, folder_format3)


                # # Check and process folder 1
                  if os.path.exists(folder_path1):
                      print(f"Processing folder: {folder_path1}")
                      process_fiber_data(folder_path1)

                # Check and process folder 2
                  if os.path.exists(folder_path2):
                      print(f"Processing folder: {folder_path2}")
                      process_fiber_data(folder_path2)
                # Check and process folder 3
                  if os.path.exists(folder_path3):
                      print(f"Processing folder: {folder_path3}")
                      process_fiber_data(folder_path3)



# Data extraction function
def extract_threshold_saturation_data(base_folder, fiber_type):
    input_file = get_input_path(base_folder, fiber_type)
    if not os.path.exists(input_file):
        raise FileNotFoundError(f"File {input_file} does not exist.")

    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    threshold_data = {
        'mean_threshold': None,
        'threshold_std': None,
        'mean_saturation': None,
        'saturation_std': None
    }

    for line in lines:
        if line.startswith("Mean Threshold"):
            threshold_data['mean_threshold'] = float(line.split(":")[1].strip())
        elif line.startswith("Threshold Standard Deviation"):
            threshold_data['threshold_std'] = float(line.split(":")[1].strip())
        elif line.startswith("Mean Saturation"):
            threshold_data['mean_saturation'] = float(line.split(":")[1].strip())
        elif line.startswith("Saturation Standard Deviation"):
            threshold_data['saturation_std'] = float(line.split(":")[1].strip())

    return threshold_data


# Bar chart plotting function
def plot_threshold_saturation_bar_chart(fiber_types, data, output_path):
    plt.rcParams['font.family'] = 'Arial'  # Or other fonts like 'Times New Roman', 'DejaVu Sans'
    plt.rcParams['svg.fonttype'] = 'none'  # Ensure text in SVG files is editable
    plt.rcParams['pdf.fonttype'] = 42  # Ensure fonts are embedded as vectors

    mean_thresholds = [abs(data[fiber]['mean_threshold']) for fiber in fiber_types]
    threshold_stds = [data[fiber]['threshold_std'] for fiber in fiber_types]
    mean_saturations = [abs(data[fiber]['mean_saturation']) for fiber in fiber_types]
    saturation_stds = [data[fiber]['saturation_std'] for fiber in fiber_types]

    x = np.arange(2)  # Two groups: Mean Threshold and Mean Saturation
    width = 0.2  # Bar width

    fig, ax = plt.subplots(figsize=(10, 6))

    for i, fiber in enumerate(fiber_types):
        hatch_threshold = '//' if mean_thresholds[i] >= 1 else None
        hatch_saturation = '//' if mean_saturations[i] >= 1 else None

        # Plot threshold bar chart, displaying cutoff if exceeding 1
        ax.bar(x[0] - width * 1.5 + i * width, [min(mean_thresholds[i], 2)], width,
               label=fiber, color=colors[i], yerr=[threshold_stds[i]], capsize=5, hatch=hatch_threshold)

        # Plot saturation bar chart, displaying cutoff if exceeding 1
        ax.bar(x[1] - width * 1.5 + i * width, [min(mean_saturations[i], 2)], width,
               color=colors[i], yerr=[saturation_stds[i]], capsize=5, hatch=hatch_saturation)

    # ax.set_xlabel('Mean Threshold and Mean Saturation')
    ax.set_ylabel('Amplitude (mA)', fontsize=32)
    # ax.set_title('Mean Threshold and Saturation with Standard Deviations for Different Fiber Types')
    ax.set_xticks(x)
    ax.set_xticklabels(['Threshold', 'Saturation'],fontsize=32)
    ax.tick_params(axis='both', which='major', labelsize=32)

    # Remove top and right borders
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # ax.legend()

    # Mark values exceeding 1
    for i, fiber in enumerate(fiber_types):
        if mean_thresholds[i] > 1:
            # ax.text(x[0] - width * 1.5 + i * width, 2.1, f'>{mean_thresholds[i]:.2f}', ha='center', color='black')
            ax.text(x[0] - width * 1.5 + i * width, 2.1, f'>1', ha='center', color='black')
        if mean_saturations[i] > 1:
            ax.text(x[1] - width * 1.5 + i * width, 2.1, f'>1', ha='center', color='black')
        # if mean_saturations[i] > 2:
        #     ax.text(x[1] - width * 1.5 + i * width, 2.1, f'>{mean_saturations[i]:.2f}', ha='center', color='black')

    plt.tight_layout()
    plt.savefig(output_path)

    output_path_svg = output_path.replace('.png', '.svg')  # Modify output path to .svg extension
    plt.savefig(output_path_svg, format='svg')




# Batch process and extract data
def process_fiber_data(base_folder):
    data = {}
    for fiber_type in fiber_types:
        try:
            data[fiber_type] = extract_threshold_saturation_data(base_folder, fiber_type)
        except FileNotFoundError as e:
            print(e)

    # Plot and save images
    output_chart_path = os.path.join(base_folder, "BS_threshold_saturation_bar_chart_with_hatch.png")
    plot_threshold_saturation_bar_chart(fiber_types, data, output_chart_path)


# Main function to batch process all matching folders
if __name__ == "__main__":
    batch_process_folders(base_input_path)
