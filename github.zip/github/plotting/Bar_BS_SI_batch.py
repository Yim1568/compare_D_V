import os
import matplotlib.pyplot as plt

# Define root path
base_input_path = r'The parent directory of DS_DR_ME_L4ptr.'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']

# Read data from BS_overall_MaxSi.txt file
def read_max_selectivity_indices(file_path):
    max_selectivity_values = {}
    fiber_std_devs = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()[1:]  # Skip header line
            for line in lines:
                parts = line.strip().split('\t')
                if len(parts) == 5:  # Check if there are 4 columns
                    fiber_type, max_si, std_dev, amp_value, std_amp_value = parts
                    max_selectivity_values[fiber_type] = float(max_si) if max_si != 'None' else None
                    fiber_std_devs[fiber_type] = float(std_dev) if std_dev != 'None' else None
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Error reading file: {file_path} - {e}")

    return max_selectivity_values, fiber_std_devs

# Plot bar chart
def plot_bar_chart(folder_name, max_selectivity_values, fiber_std_devs):
    plt.rcParams['font.family'] = 'Arial'  # Or others like 'Times New Roman', 'DejaVu Sans'
    plt.rcParams['svg.fonttype'] = 'none'  # Ensure text in SVG files is editable

    # plt.figure(figsize=(8, 6))
    fig, ax = plt.subplots(figsize=(8, 6))

    # Extract simplified x-axis labels (remove "_fibers" suffix)
    fiber_names = [fiber.replace('_fibers', '') for fiber in max_selectivity_values.keys()]
    max_values = [value if value is not None else 0 for value in max_selectivity_values.values()]
    std_devs = [fiber_std_devs[fiber] if fiber_std_devs[fiber] is not None else 0 for fiber in fiber_types]

    # Plot bar chart with error bars (standard deviation)
    plt.bar(fiber_names, max_values, color=['blue', 'green', 'red', 'orange'], yerr=std_devs, capsize=12,
            error_kw={'elinewidth': 2, 'alpha': 0.7})

    # plt.xlabel('Muscle Types')
    plt.ylabel('Max selectivity index', fontsize=36)
    # plt.title(f'Max Selectivity Index for {folder_name}')
    plt.ylim(-1, 1)
    ax.tick_params(axis='both', which='major', labelsize=36)

    # Add value labels on top of each bar
    for i, value in enumerate(max_values):
        plt.text(i, value + 0.05, f'{value:.4f}', ha='center', va='bottom',fontsize=20)

    # Remove grid lines
    plt.grid(False)

    # Remove top and right borders
    ax = plt.gca()
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    output_path = os.path.join(base_input_path, folder_name, 'BS_Bar_batch_MaxSi_.png')
    plt.savefig(output_path)

    output_path_svg = output_path.replace('.png', '.svg')  # Change output path to .svg extension
    plt.savefig(output_path_svg, format='svg')
    plt.close()
    print(f"Bar chart saved to {output_path}, with grid lines and top/right borders removed.")

# Process single folder
def process_folder(base_path, folder_name):
    file_path = os.path.join(base_path, folder_name, 'BS_overall_MaxSi.txt')
    if os.path.exists(file_path):
        print(f"Processing file: {file_path}")
        max_si_values, std_devs = read_max_selectivity_indices(file_path)
        plot_bar_chart(folder_name, max_si_values, std_devs)
    else:
        print(f"File not found: {file_path}")

# Batch process folders
for p in ['D', 'V']:
    for o in range(2, 7):
        # Process folders in pS_pR_ME_Loptr format
        process_folder(base_input_path, f'{p}S_{p}R_ME_L{o}ptr')

        # Process folders in pS_pR_ME_LoptpLi format
        for i in range(2, 7):
            process_folder(base_input_path, f'{p}S_{p}R_ME_L{o}ptpL{i}')

            # Process folders in pS_pR_ME_L{o}_mL{m}_L{i} format
            for m in range(2, 7):
                process_folder(base_input_path, f'{p}S_{p}R_ME_L{o}_mL{m}_L{i}')