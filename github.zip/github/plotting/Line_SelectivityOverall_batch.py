import os
import numpy as np
import matplotlib.pyplot as plt

# Define root path
base_input_path = r'The parent directory of DS_DR_ME_L4ptr\'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']
colors = ['blue', 'green', 'red', 'orange']  # Colors for different fiber types

# Extract data from overall_bootstrap_analysis.txt
def extract_mean_activation_ratios(file_path):
    amp_activation_ratios = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            start_idx = None
            for i, line in enumerate(lines):
                if line.startswith("Amp Value"):
                    start_idx = i + 1
                    break
            if start_idx:
                for line in lines[start_idx:]:
                    parts = line.split()
                    if len(parts) == 3:
                        amp_value = float(parts[0])
                        mean_activation_ratio = float(parts[1])
                        amp_activation_ratios[amp_value] = mean_activation_ratio
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Error reading file: {file_path} - {e}")
    return amp_activation_ratios


# Calculate selectivity index
def calculate_selectivity_index(amp_activation_ratios, fiber_type, amp_value):
    if amp_value not in amp_activation_ratios[fiber_type]:
        raise KeyError(f"Amp value {amp_value} not found in fiber {fiber_type}")

    REC_m = amp_activation_ratios[fiber_type][amp_value]

    # Calculate the average activation rate of other fibers
    other_fibers_mean = np.mean([
        amp_activation_ratios[other_fiber][amp_value]
        for other_fiber in fiber_types if other_fiber != fiber_type
    ])

    # Calculate selectivity based on the formula
    SI_m = REC_m - other_fibers_mean
    return SI_m


# Batch process folders
def process_folders(base_input_path):
    for p in ['V', 'D']:  # Add 'D' or other identifiers as needed
        for o in range(2, 7):
            # Process folders in the form of pS_pR_ME_Loptr
            folder_name = f'{p}S_{p}R_ME_L{o}ptr'
            folder_path = os.path.join(base_input_path, folder_name)
            if os.path.exists(folder_path):
                print(f"Processing folder: {folder_name}")
                process_single_folder(folder_path)

            # Process folders in the form of pS_pR_ME_LoptpLi
            for i in range(2, 7):
                folder_name = f'{p}S_{p}R_ME_L{o}ptpL{i}'
                folder_path = os.path.join(base_input_path, folder_name)
                if os.path.exists(folder_path):
                    print(f"Processing folder: {folder_name}")
                    process_single_folder(folder_path)

            # Process folders in the form of pS_pR_ME_L{o}_mL{m}_L{i}
            for m in range(2, 7):
                for i in range(2, 7):
                    folder_name = f'{p}S_{p}R_ME_L{o}_mL{m}_L{i}'
                    folder_path = os.path.join(base_input_path, folder_name)
                    if os.path.exists(folder_path):
                        print(f"Processing folder: {folder_name}")
                        process_single_folder(folder_path)


# Process a single folder
def process_single_folder(folder_path):
    fiber_activation_ratios = {}
    selectivity_results = {}

    # Extract activation rate data for each fiber
    for fiber_type in fiber_types:
        overall_file = os.path.join(folder_path, fiber_type, 'rx', 'BS_result', 'overall_bootstrap_analysis.txt')
        fiber_activation_ratios[fiber_type] = extract_mean_activation_ratios(overall_file)

    amp_values = list(fiber_activation_ratios[fiber_types[0]].keys())

    # Calculate selectivity index
    for amp_value in amp_values:
        for fiber_type in fiber_types:
            try:
                SI_m = calculate_selectivity_index(fiber_activation_ratios, fiber_type, amp_value)
            except KeyError as e:
                print(f"Error: {e}")
                continue

            if fiber_type not in selectivity_results:
                selectivity_results[fiber_type] = {}
            selectivity_results[fiber_type][amp_value] = SI_m

    # Plot selectivity index chart
    plot_selectivity_index(selectivity_results, folder_path)


# Plot line chart of selectivity index
def plot_selectivity_index(selectivity_results, folder_path):
    plt.rcParams['font.family'] = 'Arial'  # Or others like 'Times New Roman', 'DejaVu Sans'
    plt.rcParams['svg.fonttype'] = 'none'

    fig, ax = plt.subplots(figsize=(10, 6))

    for fiber_type, color in zip(fiber_types, colors):
        amp_values_abs = [abs(amp_value) for amp_value in selectivity_results[fiber_type].keys()]
        selectivity_indices = list(selectivity_results[fiber_type].values())

        plt.plot(amp_values_abs, selectivity_indices, label=fiber_type, color=color)

    # Add legend and labels
    plt.xlabel('Stimulation amplitude (mA)', fontsize=40)
    plt.ylabel('Selectivity index', fontsize=40)

    # Remove legend
    # plt.legend()
    plt.ylim(-1, 1)
    plt.xlim(0, 1.0)
    plt.grid(False)
    ax.tick_params(axis='both', which='major', labelsize=34)

    # Adjust the position of the y-axis tick numbers
    ax.yaxis.set_tick_params(pad=20)  # Reduce pad value to bring tick numbers closer to the left

    # Remove top and right border lines
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Save image or display
    output_path = os.path.join(folder_path, 'BS_selectivity_amplitude_overall.png')
    plt.savefig(output_path)
    # SVG format
    output_path_svg = output_path.replace('.png', '.svg')  # Modify output path to .svg extension
    plt.savefig(output_path_svg, format='svg')
    plt.close()


# Run batch processing
process_folders(base_input_path)
