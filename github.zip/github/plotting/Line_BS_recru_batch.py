import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
# Base input path
base_input_path = r'The parent directory of DS_DR_ME_L4ptr\'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']
colors = ['blue', 'green', 'red', 'orange']  # Colors for different fiber types

# Define path parameters
p_values = ['D', 'V']
o_range = range(2, 7)  # o range from 2 to 6
i_range = range(2, 7)  # i range from 2 to 6
m_range = range(2, 7)  # m range from 2 to 6

# General path retrieval function
def get_input_path(fiber_type, folder_path, file_name='overall_bootstrap_analysis.txt'):
    return os.path.join(folder_path, fiber_type, 'rx', 'BS_result', file_name)

# Data extraction function, only retrieving amplitude values within a specified range
def extract_activation_data(fiber_type, folder_path):
    target_amp_values = np.arange(0.0, 1.025, 0.025)  # 
    amp_values, mean_activation_ratios, std_activation_ratios = [], [], []

    input_path = get_input_path(fiber_type, folder_path)

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"File {input_path} does not exist.")

    with open(input_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 3:
                try:
                    amp, ratio, std_dev = float(parts[0]), float(parts[1]), float(parts[2])
                    if np.isclose(amp, target_amp_values, atol=1e-3).any():
                        amp_values.append(amp)
                        mean_activation_ratios.append(ratio)
                        std_activation_ratios.append(std_dev)
                except ValueError:
                    continue  # Skip lines that cannot be parsed

    return amp_values, mean_activation_ratios, std_activation_ratios


# Plot activation ratio line chart (with data points)
def plot_activation_ratio_line_chart(amp_values, mean_activation_ratios, std_activation_ratios, fiber_types,
                                     output_path):
    plt.rcParams['font.family'] = 'Arial'  # Or other options like 'Times New Roman', 'DejaVu Sans'
    plt.rcParams['svg.fonttype'] = 'none'  # 

    fig, ax = plt.subplots(figsize=(10, 6))

    for i, fiber_type in enumerate(fiber_types):
        mean_ratios = mean_activation_ratios[fiber_type]
        std_ratios = std_activation_ratios[fiber_type]
        abs_amp_values = [abs(amp) for amp in amp_values]  # Take absolute values of amplitude

        # Plot line
        ax.plot(abs_amp_values, mean_ratios, color=colors[i], linestyle='-', marker=None)

        # Plot standard deviation area
        ax.fill_between(abs_amp_values, np.array(mean_ratios) - np.array(std_ratios),
                        np.array(mean_ratios) + np.array(std_ratios), color=colors[i], alpha=0.2)

    ax.set_xlabel('Stimulation amplitude (mA)', fontsize=36)
    ax.set_ylabel('Recruitment (%)', fontsize=36, labelpad=-10)
    ax.tick_params(axis='both', which='major', labelsize=36)

    # Adjust vertical axis tick label position
    ax.yaxis.set_tick_params(pad=20)  # Reduce pad value to move tick labels closer to the left

    # Format vertical axis as percentage
    ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f'{y * 100:.0f}'))

    # Remove grid lines
    plt.grid(False)

    # Remove top and right borders
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.ylim(0, 1)  # Ensure vertical axis range is 0 to 1
    plt.xlim(0, 1.0)
    plt.tight_layout()

    # Save image as .png and .svg format
    plt.savefig(output_path, format='png')

    output_path_svg = output_path.replace('.png', '.svg')  # Change output path extension to .svg
    plt.savefig(output_path_svg, format='svg')

    plt.close()




# Logic for processing a single folder
def process_single_folder(folder_name):
    folder_path = os.path.join(base_input_path, folder_name)

    if not os.path.exists(folder_path):
        print(f"Folder {folder_path} does not exist.")
        return

    mean_activation_ratios_all_fibers = {}
    std_activation_ratios_all_fibers = {}
    amp_values_all_fibers = {}

    for fiber_type in fiber_types:
        try:
            amp_values, mean_ratios, std_ratios = extract_activation_data(fiber_type, folder_path)
            amp_values_all_fibers[fiber_type] = amp_values
            mean_activation_ratios_all_fibers[fiber_type] = mean_ratios
            std_activation_ratios_all_fibers[fiber_type] = std_ratios
        except FileNotFoundError as e:
            print(e)

    if 'GC_fibers' in amp_values_all_fibers:
        output_line_chart_path = os.path.join(folder_path, f"BS_activation_ratio_line_chart_{folder_name}.png")
        plot_activation_ratio_line_chart(amp_values_all_fibers['GC_fibers'],
                                         mean_activation_ratios_all_fibers,
                                         std_activation_ratios_all_fibers,
                                         fiber_types, output_line_chart_path)

# General logic for processing folder structure
def process_folder_structure(folder_name_template, o_range, i_range=None, m_range=None):
    for p in p_values:
        for o in o_range:
            if i_range and m_range:
                for m in m_range:
                    for i in i_range:
                        folder_name = folder_name_template.format(p=p, o=o, m=m, i=i)
                        process_single_folder(folder_name)
            elif i_range:
                for i in i_range:
                    folder_name = folder_name_template.format(p=p, o=o, i=i)
                    process_single_folder(folder_name)
            else:
                folder_name = folder_name_template.format(p=p, o=o)
                process_single_folder(folder_name)

# Batch processing
def process_folders():
    process_folder_structure('{p}S_{p}R_ME_L{o}ptr', o_range)
    process_folder_structure('{p}S_{p}R_ME_L{o}ptpL{i}', o_range, i_range=i_range)
    process_folder_structure('{p}S_{p}R_ME_L{o}_mL{m}_L{i}', o_range, i_range=i_range, m_range=m_range)

# Execute batch processing
process_folders()
