import os
import random
import time
import numpy as np
''''
Implement Bootstrap stimulation

'''

# Input and output paths
input_folder = r'currentpatheway\DS_DR_ME_L4ptr'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']

def read_activation_results(result_path, amp_values):
    activation_results = {}
    for amp in amp_values:
        amp_file = os.path.join(result_path, f"{amp}_results.txt")
        if os.path.exists(amp_file):
            with open(amp_file, "r", encoding="utf-8") as f:
                activations = {}
                for line in f:
                    file_name, status = line.strip().split(", ")
                    activations[file_name] = int(status)
                activation_results[amp] = activations
        else:
            print(f"Warning: {amp_file} not found.")
            activation_results[amp] = None  # Mark as None, indicating the amplitude file doesn't exist
    return activation_results

def calculate_threshold_and_saturation(total_recr, amp_values, fn=40):
    target_threshold = 0.1 * fn
    target_saturation = 0.9 * fn

    threshold_candidates = []
    saturation_candidates = []

    for i in range(1, len(total_recr)):
        prev_activation = total_recr[i - 1]
        curr_activation = total_recr[i]
        prev_amp = amp_values[i - 1]
        curr_amp = amp_values[i]

        if curr_activation != prev_activation:
            if prev_activation <= target_threshold <= curr_activation:
                interpolated_threshold = prev_amp + (target_threshold - prev_activation) * (curr_amp - prev_amp) / (curr_activation - prev_activation)
                threshold_candidates.append(interpolated_threshold)

            if prev_activation <= target_saturation <= curr_activation:
                interpolated_saturation = prev_amp + (target_saturation - prev_activation) * (curr_amp - prev_amp) / (curr_activation - prev_activation)
                saturation_candidates.append(interpolated_saturation)

    if not threshold_candidates:
        threshold_candidates.append(amp_values[-1])

    if not saturation_candidates:
        if total_recr[-1] <= target_saturation:
            saturation_candidates.append(amp_values[-1])

    threshold = min(threshold_candidates, key=abs) if threshold_candidates else None
    saturation = min(saturation_candidates, key=abs) if saturation_candidates else None

    return threshold, saturation

def perform_bootstrap_resampling(fiber_files, amp_values, activation_results, num_resamples=10000, output_dir=None):
    start_time = time.time()  # Start timer
    thresholds = []
    saturations = []
    amp_activation_ratios = {amp: [] for amp in amp_values}

    for resample_idx in range(num_resamples):
        resampled_files = random.choices(fiber_files, k=40)
        total_recr = []
        stop_flag = False

        with open(os.path.join(output_dir, f"resample_{resample_idx + 1}_results.txt"), "w", encoding="utf-8") as res_file:
            res_file.write(f"Resample {resample_idx + 1}:\n")
            res_file.write(f"Resampled Files: {', '.join(os.path.basename(f) for f in resampled_files)}\n\n")
            res_file.write("Amp Value\tActivated Fibers\tActivation Ratio\n")

            for amp in amp_values:
                if stop_flag:
                    total_recr.append(40)
                    res_file.write(f"{abs(amp)}\t40\t1.000\n")
                    continue

                if activation_results[amp] is None:  # If the amplitude file is not found
                    activation_count = 40
                else:
                    activation_count = sum(
                        activation_results[amp].get(os.path.basename(file), 0) for file in resampled_files
                    )

                total_recr.append(activation_count)
                activation_ratio = activation_count / 40 if activation_count > 0 else 0.0
                amp_activation_ratios[amp].append(activation_ratio)
                res_file.write(f"{abs(amp)}\t{activation_count}\t{activation_ratio:.3f}\n")

                if activation_ratio == 1.0:
                    stop_flag = True

            threshold, saturation = calculate_threshold_and_saturation(total_recr, amp_values)
            thresholds.append(threshold)
            saturations.append(saturation)

            res_file.write(f"\nThreshold: {abs(threshold)}\nSaturation: {abs(saturation)}\n")

    mean_activation_ratios = {}
    std_activation_ratios = {}

    for amp, ratios in amp_activation_ratios.items():
        if ratios:
            mean_activation_ratios[amp] = np.mean(ratios)
            std_activation_ratios[amp] = np.std(ratios)
        else:
            mean_activation_ratios[amp] = 1.0
            std_activation_ratios[amp] = 0.0

    with open(os.path.join(output_dir, "overall_bootstrap_analysis.txt"), "w", encoding="utf-8") as analysis_file:
        analysis_file.write(f"Mean Threshold: {abs(np.mean(thresholds)):.3f}\n")
        analysis_file.write(f"Threshold Standard Deviation: {np.std(thresholds):.3f}\n")
        analysis_file.write(f"Mean Saturation: {abs(np.mean(saturations)):.3f}\n")
        analysis_file.write(f"Saturation Standard Deviation: {np.std(saturations):.3f}\n\n")
        analysis_file.write("Amp Value\tMean Activation Ratio\tStandard Deviation\n")
        for amp in amp_values:
            analysis_file.write(f"{abs(amp)}\t{mean_activation_ratios[amp]:.3f}\t{std_activation_ratios[amp]:.3f}\n")

    end_time = time.time()  # End timer
    print(f"perform_bootstrap_resampling completed in {end_time - start_time:.2f} seconds")

def process_folder(folder_path):
    total_start_time = time.time()  # Script total runtime start
    amp_values = [round(0 + i * -0.025, 3) for i in range(0, 41)]   # Note different ranges for D and V

    for fiber_type in fiber_types:
        rx_path = os.path.join(folder_path, fiber_type, 'rx')
        result_path = os.path.join(rx_path, 'result')
        output_dir = os.path.join(rx_path, 'BS_result')
        os.makedirs(output_dir, exist_ok=True)

        # Get actual files matching rx_L{n}_f{m}.txt pattern
        fiber_files = [
            os.path.join(rx_path, file)
            for file in os.listdir(rx_path)
            if any(f"rx_L{n}_F{m}.txt" == file for n in range(2, 7) for m in range(1, 33))
        ]

        activation_results = read_activation_results(result_path, amp_values)

        if fiber_files:
            perform_bootstrap_resampling(fiber_files, amp_values, activation_results, output_dir=output_dir)
        else:
            print(f"No files found in {result_path}.")

    total_end_time = time.time()  # Script total runtime end
    print(f"Total script runtime: {total_end_time - total_start_time:.2f} seconds")

process_folder(input_folder)