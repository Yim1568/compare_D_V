import os
import shutil
import random
import matplotlib.pyplot as plt
from neuron import h, gui

'''
once stimualtion
'''

# Base path: directory containing all fiber files
base_path = r'current_pathway\DS_DR_ME_L4ptr'

# Fiber type list
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']

# Check and delete existing result folders
for fiber_type in fiber_types:
    result_dir = os.path.join(base_path, fiber_type, 'rx', 'result')
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir)  # Delete the result folder and its contents
    os.makedirs(result_dir, exist_ok=True)  # Create a new result folder

# NEURON simulation: load and set data
def load_and_set_data(file_name, amp_value):
    try:
        h.load_file("sensory_fiber.hoc")
        # h.load_file("motor_fiber.hoc")
        h('objref f')
        h('f = new File()')
        h.f.ropen(file_name)

        h.load_file("setrx.hoc")
        h.setpointers()

        h(f'amp_value = {amp_value}')
        h.load_file("stim_bipha_square.hoc")
        h.biphasic(1, amp_value, 0.2, 0.02, 50, 1000)  # 50HZ

        v = h.Vector().record(h.Afibre.node[0](0.5)._ref_v)
        h.run()

        activated = any(membrane_potential > -50 for membrane_potential in v)
        return activated

    except Exception as e:
        print(f"Failed to process file: {file_name}\nError: {e}")
        return False
    finally:
        h('f.close()')
        h('objref f')

# Align data to ensure x and y have the same length
def align_data(x_values, y_values):
    if len(x_values) > len(y_values):
        y_values.extend([y_values[-1]] * (len(x_values) - len(y_values)))
    elif len(y_values) > len(x_values):
        y_values = y_values[:len(x_values)]
    return x_values, y_values

# Process activation data for a specific fiber type
def process_fiber_type(fiber_type):
    input_path = os.path.join(base_path, fiber_type, 'rx')
    output_dir = os.path.join(base_path, fiber_type, 'rx', 'result')

    amp_values = [round(0 + i * -0.025, 3) for i in range(0, 41)]
    activation_percentages = []

    threshold = None
    saturation = None
    amp_activation_ratios = {}
    stop_processing = False  # Add stop flag

    for amp_value in amp_values:
        if stop_processing:
            break  # Exit the loop if the activation reaches 100%

        total_files = 0
        activated_count = 0

        for n in range(2, 7):
            for m in range(1, 33):
                file_name = os.path.join(input_path, f"rx_L{n}_F{m}.txt")

                if os.path.exists(file_name):
                    total_files += 1
                    activated = load_and_set_data(file_name, amp_value)

                    output_file = os.path.join(output_dir, f"{amp_value}_results.txt")
                    with open(output_file, "a") as result_file:
                        result_file.write(f"{os.path.basename(file_name)}, {'1' if activated else '0'}\n")

                    if activated:
                        activated_count += 1

        if total_files > 0:
            activation_percentage = (activated_count / total_files) * 100
            activation_percentages.append(activation_percentage)
            amp_activation_ratios[amp_value] = activation_percentage / 100
        else:
            activation_percentages.append(0)

        if activation_percentage >= 100:  # Stop processing if 100% activation is reached
            stop_processing = True

    # Calculate threshold and saturation based on activation ratios
    amp_values_list = list(amp_activation_ratios.keys())
    mean_ratios = list(amp_activation_ratios.values())

    # Check if threshold and saturation can be directly assigned
    for amp_value, mean_activation_ratio in amp_activation_ratios.items():
        if mean_activation_ratio == 0.1:
            if threshold is None or abs(amp_value) < abs(threshold):
                threshold = amp_value
        if mean_activation_ratio == 0.9:
            if saturation is None or abs(amp_value) < abs(saturation):
                saturation = amp_value

    # If threshold or saturation are still None, use interpolation
    if threshold is None or saturation is None:
        if threshold is None:
            for i in range(1, len(mean_ratios)):
                prev_activation = mean_ratios[i - 1]
                curr_activation = mean_ratios[i]
                prev_amp = amp_values_list[i - 1]
                curr_amp = amp_values_list[i]

                if prev_activation <= 0.1 <= curr_activation:
                    threshold = prev_amp + (0.1 - prev_activation) * (curr_amp - prev_amp) / (
                                curr_activation - prev_activation)
                    break

        if saturation is None:
            for i in range(1, len(mean_ratios)):
                prev_activation = mean_ratios[i - 1]
                curr_activation = mean_ratios[i]
                prev_amp = amp_values_list[i - 1]
                curr_amp = amp_values_list[i]

                if prev_activation <= 0.9 <= curr_activation:
                    saturation = prev_amp + (0.9 - prev_activation) * (curr_amp - prev_amp) / (
                                curr_activation - prev_activation)
                    break

    if threshold is None:
        threshold = min(amp_values)
    if saturation is None:
        saturation = max(abs(amp) for amp in amp_values)



    thres_satu_file = os.path.join(output_dir, 'OverallAnalysis.txt')
    with open(thres_satu_file, 'w') as f:
        f.write(f"Threshold: {abs(threshold):.3f}\n")

        f.write(f"Saturation: {abs(saturation):.3f}\n")

        f.write(f"Amp Value\tActivation Ratio\n")

        for amp_value in amp_values:
            if amp_value in amp_activation_ratios:
                mean_activation_ratio = amp_activation_ratios[amp_value]
            else:
                mean_activation_ratio = 1.0  # Default value for unprocessed amplitudes


            f.write(f"{abs(amp_value):.3f}\t{mean_activation_ratio:.3f}\n")

    return amp_values, activation_percentages

# Process all fiber types
all_fiber_activations = {}
for fiber_type in fiber_types:
    amp_values, activation_percentages = process_fiber_type(fiber_type)
    all_fiber_activations[fiber_type] = activation_percentages