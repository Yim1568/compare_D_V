import os
import numpy as np
'''
caculate SI
'''
# Define base path
base_path = r'current pathway\ DS_DR_ME_L4ptr'
fiber_types = ['GC_fibers', 'TA_fibers', 'ST_fibers', 'VM_fibers']

# Extract data from resample_{n}_results.txt
def extract_mean_activation_ratios(file_path):
    amp_activation_ratios = {}
    threshold = None
    saturation = None
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            start_idx = None
            for i, line in enumerate(lines):
                if line.startswith("Amp Value"):
                    start_idx = i + 1
                elif start_idx and i >= start_idx:
                    parts = line.split()
                    if len(parts) == 3:
                        amp_value = abs(float(parts[0]))
                        mean_activation_ratio = abs(float(parts[2]))
                        amp_activation_ratios[amp_value] = mean_activation_ratio

                        if mean_activation_ratio == 0.1:
                            if threshold is None or amp_value < threshold:
                                threshold = amp_value
                        if mean_activation_ratio == 0.9:
                            if saturation is None or amp_value < saturation:
                                saturation = amp_value

        if threshold is None or saturation is None:
            amp_values = list(amp_activation_ratios.keys())
            mean_ratios = list(amp_activation_ratios.values())
            if threshold is None:
                for i in range(1, len(mean_ratios)):
                    prev_activation = mean_ratios[i - 1]
                    curr_activation = mean_ratios[i]
                    prev_amp = amp_values[i - 1]
                    curr_amp = amp_values[i]

                    if prev_activation <= 0.1 <= curr_activation:
                        threshold = prev_amp + (0.1 - prev_activation) * (curr_amp - prev_amp) / (
                                    curr_activation - prev_activation)
                        break

            if saturation is None:
                for i in range(1, len(mean_ratios)):
                    prev_activation = mean_ratios[i - 1]
                    curr_activation = mean_ratios[i]
                    prev_amp = amp_values[i - 1]
                    curr_amp = amp_values[i]

                    if prev_activation <= 0.9 <= curr_activation:
                        saturation = prev_amp + (0.9 - prev_activation) * (curr_amp - prev_amp) / (
                                    curr_activation - prev_activation)
                        break

        if threshold is None:
            threshold = max(amp_values)
        if saturation is None:
            saturation = max(amp_values)

    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Error reading file: {file_path} - {e}")

    return amp_activation_ratios, threshold, saturation

# Selectivity index calculation
def calculate_selectivity_index(amp_activation_ratios, fiber_type, amp_value):
    REC_m = amp_activation_ratios[fiber_type][amp_value]

    other_fibers_mean = np.mean([
        amp_activation_ratios[other_fiber][amp_value]
        for other_fiber in fiber_types if other_fiber != fiber_type and amp_value in amp_activation_ratios[other_fiber]
    ])

    SI_m = REC_m - other_fibers_mean
    return round(SI_m, 5)


def process_folder(folder_path):
    # Check if folder exists
    if not os.path.exists(folder_path):
        print(f"Folder not found: {folder_path}. Skipping...")
        return

    all_resample_max_selectivity_values = {fiber_type: [] for fiber_type in fiber_types}
    all_resample_max_amp_values = {fiber_type: [] for fiber_type in fiber_types}

    for n in range(1, 10001):
        fiber_activation_ratios = {}
        fiber_thresholds = {}
        fiber_saturations = {}

        for fiber_type in fiber_types:
            overall_file = os.path.join(folder_path, fiber_type, 'rx', 'BS_result', f'resample_{n}_results.txt')
            activation_ratios, threshold, saturation = extract_mean_activation_ratios(overall_file)
            fiber_activation_ratios[fiber_type] = activation_ratios
            fiber_thresholds[fiber_type] = threshold
            fiber_saturations[fiber_type] = saturation

        selectivity_results = {fiber_type: {} for fiber_type in fiber_types}

        for fiber_type in fiber_types:
            threshold = fiber_thresholds[fiber_type]
            saturation = fiber_saturations[fiber_type]

            for amp_value in fiber_activation_ratios[fiber_type].keys():
                if threshold is not None and saturation is not None and threshold <= amp_value <= saturation:
                    try:
                        SI_m = calculate_selectivity_index(fiber_activation_ratios, fiber_type, amp_value)
                        selectivity_results[fiber_type][amp_value] = SI_m
                    except KeyError as e:
                        continue

        max_selectivity_values = {}
        max_amp_values = {}

        for fiber_type in fiber_types:
            if selectivity_results[fiber_type]:
                max_amp_value = max(selectivity_results[fiber_type], key=selectivity_results[fiber_type].get)
                max_selectivity = selectivity_results[fiber_type][max_amp_value]
                max_amp_values[fiber_type] = max_amp_value
            else:
                max_selectivity = None
                max_amp_value = None

            max_selectivity_values[fiber_type] = max_selectivity

            if max_selectivity is not None:
                all_resample_max_selectivity_values[fiber_type].append(max_selectivity)
            if max_amp_value is not None:
                all_resample_max_amp_values[fiber_type].append(max_amp_value)

        # Write maximum selectivity values to si_all folder for each fiber_type
        for fiber_type, max_value in max_selectivity_values.items():
            si_folder = os.path.join(folder_path, fiber_type, 'si_all')
            os.makedirs(si_folder, exist_ok=True)  # Ensure si_all folder exists

            output_file = os.path.join(si_folder, f'resample_{n}_selectivity_results.txt')
            with open(output_file, 'w', encoding='utf-8') as f_out:
                f_out.write("Fiber Type\tMax Selectivity Index\n")
                if max_value is not None:
                    f_out.write(f"{fiber_type}\t{max_value:.5f}\n")
                else:
                    f_out.write(f"{fiber_type}\tNone\n")

            print(f"\nSelectivity index results saved to file: {output_file}")

    overall_output_file = os.path.join(folder_path, 'BS_overall_MaxSi.txt')
    with open(overall_output_file, 'w', encoding='utf-8') as overall_f_out:
        overall_f_out.write("Fiber Type\tMax Selectivity Index\tStandard Deviation\tMean Amp Value\tStd Amp Value\n")
        for fiber_type, max_values in all_resample_max_selectivity_values.items():
            amp_values = all_resample_max_amp_values[fiber_type]
            if max_values:
                mean_selectivity = np.mean(max_values)
                std_selectivity = np.std(max_values)
                mean_amp_value = np.mean(amp_values)
                std_amp_value = np.std(amp_values)
                overall_f_out.write(f"{fiber_type}\t{mean_selectivity:.5f}\t{std_selectivity:.5f}\t{mean_amp_value:.5f}\t{std_amp_value:.5f}\n")
            else:
                overall_f_out.write(f"{fiber_type}\tNone\tNone\tNone\tNone\n")